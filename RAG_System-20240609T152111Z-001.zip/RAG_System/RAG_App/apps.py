from django.apps import AppConfig


class RagAppConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "RAG_App"
